import { Component } from '@angular/core';

@Component({
  selector: 'app-another-children-routing',
  templateUrl: './another-children-routing.component.html',
  styleUrls: ['./another-children-routing.component.scss']
})
export class AnotherChildrenRoutingComponent {

}
