import { Component } from '@angular/core';

@Component({
  selector: 'app-children-routing',
  templateUrl: './children-routing.component.html',
  styleUrls: ['./children-routing.component.scss']
})
export class ChildrenRoutingComponent {

}
