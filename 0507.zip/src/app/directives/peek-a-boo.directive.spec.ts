import { PeekABooDirective } from './peek-a-boo.directive';

describe('PeekABooDirective', () => {
  it('should create an instance', () => {
    const directive = new PeekABooDirective();
    expect(directive).toBeTruthy();
  });
});
