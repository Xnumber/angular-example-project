export class ProviderQueryTesting {
  t = 0;
}