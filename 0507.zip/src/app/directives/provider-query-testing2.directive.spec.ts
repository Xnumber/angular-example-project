import { ProviderQueryTesting2Directive } from './provider-query-testing2.directive';

describe('ProviderQueryTesting2Directive', () => {
  it('should create an instance', () => {
    const directive = new ProviderQueryTesting2Directive();
    expect(directive).toBeTruthy();
  });
});
