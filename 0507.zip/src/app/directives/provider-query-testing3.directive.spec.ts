import { ProviderQueryTesting3Directive } from './provider-query-testing3.directive';

describe('ProviderQueryTesting3Directive', () => {
  it('should create an instance', () => {
    const directive = new ProviderQueryTesting3Directive();
    expect(directive).toBeTruthy();
  });
});
