import { SpyDirective } from './spy.directive';

describe('SpyDirective', () => {
  it('should create an instance', () => {
    const directive = new SpyDirective();
    expect(directive).toBeTruthy();
  });
});
