export const environment = {
	production: true,
	LOG_LEVEL: 'ERROR'
  };
  