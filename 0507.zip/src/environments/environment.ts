export const environment = {
	production: false,
	LOG_LEVEL: 'DEBUG'
  };
  